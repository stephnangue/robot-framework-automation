from robot.api.deco import library, keyword
from lxml import etree
#  import xmlschema
# librairie de validation XML pour Robot Framework

@library
class XMLvalidation:

    @keyword
    def String_Must_Validate_Schema(self, xmlstring, xsdfilename):
        """
        validates an XML document against an XSD schema.

        Arguments:
        - ''xmlstring:''     the content of the XML data to validate\n
        - ''xsdfilename:''   the name of the XSD schema file to use\n

        Examples:
        | String Must Validate Schema | ${xmlstring} | tests/files/schema.xsd
        """
        # lecture du schÃ©ma XSD => exception si pas valide en tant que schÃ©ma
        xmlschema_doc = etree.parse(xsdfilename)
        xmlschema = etree.XMLSchema(xmlschema_doc)

        # analyse du document XML => exception si pas bien formÃ©
        xml_doc = etree.fromstring(xmlstring.encode())

        # validation, exception si non valide
        #strict_schema.assertValid(xml_doc)
        xmlschema.assertValid(xml_doc)

        # succÃ¨s
        return "valid"


    @keyword
    def XML_Must_Validate_Schema(self, xmltree, xsdfilename):
        """
        validates an XML tree against an XSD schema.

        Arguments:
        - ''xmltree:''       the XML tree (parsed string or file) to validate\n
        - ''xsdfilename:''   the name of the XSD schema file to use\n

        Examples:
        | ${xml}= | Parse XML | ${xmlstring}
        | XML Must Validate Schema | ${xml} | tests/files/schema.xsd
        """

        # lecture du schÃ©ma XSD => exception si pas valide en tant que schÃ©ma
        xmlschema_doc = etree.parse(xsdfilename)
        xmlschema = etree.XMLSchema(xmlschema_doc)

        # validation, exception si non valide
        xmlschema.assertValid(xmltree)

        # succÃ¨s
        return "valid"


    @keyword
    def File_Must_Validate_Schema(self, xmlfilename, xsdfilename):
        """
        validates an XML file against an XSD schema.

        Arguments:
        - ''xmlfilename:''   the XML file name to validate\n
        - ''xsdfilename:''   the name of the XSD schema file to use\n

        Examples:
        | File Must Validate Schema | tests/data.xml | tests/files/schema.xsd
        """

        # lecture du schÃ©ma XSD => exception si pas valide en tant que schÃ©ma
       
        xmlschema_doc = ET.parse(xsdfilename)
        xmlschema = ET.XMLSchema(xmlschema_doc)

        # lecture du fichier XML => exception si pas bien formÃ©
        xmlfile_doc = ET.parse(xmlfilename)

        # validation, exception si non valide
        xmlschema.assertValid(xmlfile_doc)

        # succÃ¨s
        return "valid"
