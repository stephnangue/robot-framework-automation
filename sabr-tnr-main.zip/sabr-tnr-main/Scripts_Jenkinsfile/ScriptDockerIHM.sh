#!/bin/sh
set -e
# Vérifier le nombre de paramètres
if [ $# -ne 4 ]; then
    echo -e "Vous devez fournir 4 entrants au script dans l'ordre suivant : <stack de sabr> <workspace> <repertoir des profils firefox> <port du simulateur SABr>\n"
    exit 1
fi
if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ] || [ -z "$4" ]; then
    echo -e "Vous devez fournir 4 entrants au script dans l'ordre suivant : <stack de sabr> <workspace> <repertoir des profils firefox> <port du simulateur SABr>\n"
    exit 1
fi
portPabot=$((25500 + RANDOM % (49990 - 25500 +1)))
IP_ADDRESS_MOTOUR=$(host ksbrl-scxchflx01.$1.kal.sabr.znp.stet | cut -d " " -f4)
IP_ADDRESS_IHMSABR=$(host ksbrl-scsipihm01.$1.kal.sabr.znp.stet | cut -d " " -f4)
IP_ADDRESS_BDSABR=$(host ksbrl-scxchsql01.$1.kal.sabr.znp.stet | cut -d " " -f4)
# $1 correspond à la STAK KAL de SABr
# $2 correspond à l'espace de travail
# $3 correspond au repertoire des profiles firefox
# $4 correspond au port du tunnel pour le simulateur SABr
docker run --rm --net=host --user=1002:1002 -e TZ=Europe/Paris -e ROBOT_THREADS=1 -e PABOT_OPTIONS="--testlevelsplit --pabotlib --pabotlibport $portPabot --listener RetryFailed:1" -e ROBOT_OPTIONS="--variable PORT:$4 --variable IPMOTEUR:$IP_ADDRESS_MOTOUR --variable IPIHMSABR:$IP_ADDRESS_IHMSABR --variable IPBDSABR:$IP_ADDRESS_BDSABR" -e BROWSER=headlessfirefox -v $2/resources:/opt/robotframework/resources -v $2/tests/ihm:/opt/robotframework/tests:Z -v $2/reports/ihm_reports:/opt/robotframework/reports:Z -v /home/devops/.ssh:/opt/robotframework/.ssh:Z -v $3:/opt/robotframework/firefox:Z stet/robot-framework:1.3.0
