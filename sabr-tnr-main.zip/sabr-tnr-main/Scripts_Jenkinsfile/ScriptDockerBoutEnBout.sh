#!/bin/sh
set -e
# Vérifier le nombre de paramètres
if [ $# -ne 6 ]; then
    echo -e "Vous devez fournir 6 entrants au script dans l'ordre suivant : <stack de sabr> <workspace> <repertoir des profils firefox> <true> <true> <port du simulateur SABr>\n"
    exit 1
fi
if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ] || [ -z "$6" ]; then
    echo -e "Vous devez fournir 6 entrants au script dans l'ordre suivant : <stack de sabr> <workspace> <repertoir des profils firefox> <true> <true> <port du simulateur SABr>\n"
    exit 1
fi
portPabot=$((25500 + RANDOM % (49990 - 25500 +1)))
IP_ADDRESS_MOTOUR=$(host ksbrl-scxchflx01.$1.kal.sabr.znp.stet | cut -d " " -f4)
IP_ADDRESS_IHMSABR=$(host ksbrl-scsipihm01.$1.kal.sabr.znp.stet | cut -d " " -f4)
IP_ADDRESS_BDSABR=$(host ksbrl-scxchsql01.$1.kal.sabr.znp.stet | cut -d " " -f4)
# $1 correspond à la STAK KAL de SABr
# $2 correspond à l'espace de travail
# $3 correspond au repertoire des profiles firefox
# $4 est un boulean : toujour à true pour la chaine CD 
# $5 est un boulean : toujour à true pour la chaine CD 
# $6 correspond au port du tunnel pour le simulateur SABr
if [ "$4" = "true" ] && [ "$5" = "false" ]; then
    docker run --rm --net=host --user=1002:1002 -e TZ=Europe/Paris -e ROBOT_THREADS=3 -e PABOT_OPTIONS="--pabotlib --pabotlibport $portPabot --testlevelsplit --listener RetryFailed:1" -e BROWSER=headlessfirefox -e ROBOT_OPTIONS="--variable PORT:$6 --variable IPMOTEUR:$IP_ADDRESS_MOTOUR --variable IPIHMSABR:$IP_ADDRESS_IHMSABR --variable IPBDSABR:$IP_ADDRESS_BDSABR" -v $2/resources:/opt/robotframework/resources -v $2/tests/bout_en_bout/core2_sabr:/opt/robotframework/tests:Z -v $2/reports/bout_en_bout_reports:/opt/robotframework/reports:Z -v /home/devops/.ssh:/opt/robotframework/.ssh:Z -v $3:/opt/robotframework/firefox:Z stet/robot-framework:1.3.0
fi
if [ "$4" = "false" ] && [ "$5" = "true" ]; then
    docker run --rm --net=host --user=1002:1002 -e TZ=Europe/Paris -e ROBOT_THREADS=3 -e PABOT_OPTIONS="--pabotlib --pabotlibport $portPabot --testlevelsplit --listener RetryFailed:1" -e BROWSER=headlessfirefox -e ROBOT_OPTIONS="--variable PORT:$6 --variable IPMOTEUR:$IP_ADDRESS_MOTOUR --variable IPIHMSABR:$IP_ADDRESS_IHMSABR --variable IPBDSABR:$IP_ADDRESS_BDSABR" -v $2/resources:/opt/robotframework/resources -v $2/tests/bout_en_bout/core1_sabr:/opt/robotframework/tests:Z -v $2/reports/bout_en_bout_reports:/opt/robotframework/reports:Z -v /home/devops/.ssh:/opt/robotframework/.ssh:Z -v $3:/opt/robotframework/firefox:Z stet/robot-framework:1.3.0
fi
if [ "$4" = "true" ] && [ "$5" = "true" ]; then
    docker run --rm --net=host --user=1002:1002 -e TZ=Europe/Paris -e ROBOT_THREADS=3 -e PABOT_OPTIONS="--pabotlib --pabotlibport $portPabot --testlevelsplit --listener RetryFailed:1" -e BROWSER=headlessfirefox -e ROBOT_OPTIONS="--variable PORT:$6 --variable IPMOTEUR:$IP_ADDRESS_MOTOUR --variable IPIHMSABR:$IP_ADDRESS_IHMSABR --variable IPBDSABR:$IP_ADDRESS_BDSABR" -v $2/resources:/opt/robotframework/resources -v $2/tests/bout_en_bout:/opt/robotframework/tests:Z -v $2/reports/bout_en_bout_reports:/opt/robotframework/reports:Z -v /home/devops/.ssh:/opt/robotframework/.ssh:Z -v $3:/opt/robotframework/firefox:Z stet/robot-framework:1.3.0
fi


