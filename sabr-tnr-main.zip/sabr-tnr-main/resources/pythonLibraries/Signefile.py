from robot.libraries.BuiltIn import BuiltIn

try:
   import robot.api.logger as logger
   from robot.api.deco import keyword
   ROBOT = False
except Exception:
   ROBOT = False

#@keyword("ADD CONTENT XML")
class signresponse(object):
   def add_content_xml (self,fileToSign):
      chemin_absolu="/opt/robotframework/temp/" + fileToSign
      with open(chemin_absolu, "r") as in_response:
         buf_response = in_response.readlines()
      with open("/opt/robotframework/resources/variables/sign.xml", "r") as in_sign:
         buf_sign = in_sign.readlines()
      with open(chemin_absolu, "w") as out_response:
         for line_response in buf_response:
            if "<CreDt>" in line_response:
               line_response = line_response + ''.join(buf_sign)
            out_response.write(line_response)
      #return(path_response)
      with open(chemin_absolu, "r") as sign_response:
          reponse = sign_response.read() 
      #   print("hello")
      return reponse
   # with open("response.xml", "r") as sign_response:
   #     print(sign_response.read()) 
    #  print("hello")
globals()[__name__] = signresponse
#if __name__ == '__main__'
