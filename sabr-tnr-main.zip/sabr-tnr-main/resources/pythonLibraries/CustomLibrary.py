import re

class CustomLibrary:
    def add_fake_root_to_bad_xml_text(self, bad_xml_text):
        xml = re.sub(r"(<\?xml[^>]+\?>)", r"<root>", bad_xml_text) + "</root>"
        return xml

    def get_exogenous_system_conf_by_system_code(self, exogenous_system_code, json_data):
        conf = list(filter(lambda x: x.get('exogenousSystemCode') == exogenous_system_code, json_data))
        return conf

    def get_connected_settlement_agent_by_agent_code(self, settlement_agent_code, json_data):
        conf = list(filter(lambda x: x.get('settlementAgentCode') == settlement_agent_code, json_data))
        return conf
    def add_fake_root_to_bad_xml_text_V2(self, bad_xml_text):
        xml = "<root>" + bad_xml_text + "</root>"
        return xml 
