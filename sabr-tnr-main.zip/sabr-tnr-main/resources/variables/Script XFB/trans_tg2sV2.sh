#!/bin/sh
# peltrans -ml FROM_PAC1_TO_CORE
LOGFILE=/var/log/scripts/XFB/trans_tg2.log
if [ $# -eq 0 ]; then
    exit 1
fi
idMessage=$1
#peltrans -rtx $x_route_from_xfer -ty EERP >> $LOGFILE
x_route_from_xfer=$(peldsp select_trans -list_trans_state E -dest_alias GTW-PAC1 -from_date $(date +"%Y%m%d000000"))
for i in $x_route_from_xfer
do
    msg_extract=$(peldsp display_trans -i $i | grep x_rcv_msg | awk -F\' '{print$2}'|awk -F# '{print $5}')
    if [ "$msg_extract" -eq "$idMessage" ]; then
        x_state=$(peldsp display_trans -i $i | grep x_state | awk -F "=" '{print$2}' | awk -F "'" '{print$2}')
        msg_snd="${msg_extract}#$x_state"
        peltrans -rtx $i -ty EERP -snd_msg $msg_snd >> $LOGFILE
    fi
done
